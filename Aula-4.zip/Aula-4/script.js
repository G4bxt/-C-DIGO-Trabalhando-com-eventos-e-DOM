function onClick(evento) {
    console.log(evento);
    evento.srcElement.innerHTML = 'Este botão foi clicado';
    
    const paragrafo = document.querySelector('p');
    paragrafo.innerText = 'Este texto foi gerado após o clique do botão';

    // Alterando a imagem ao clicar no botão
    const imagem = document.querySelector('#imagem');
    imagem.src = 'hk2.png'; // Nova imagem
    imagem.alt = 'Imagem Alterada'; // Alterando o texto alternativo
}

const button = document.querySelector('button');
button.addEventListener('click', onClick);
